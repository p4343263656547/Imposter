// server.js - Imposter Game v3 — session persistence, typing, inactivity, kick, play-again, live votes

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const Groq = require('groq-sdk');
const path = require('path');

const { createRoom, getRoom, deleteRoom, addPlayer, getPublicState } = require('./game/rooms');
const { assignRoles } = require('./game/roles');
const { getRandomWord, addCustomWords, getAllWords, generateAIWords, ensureAIPool } = require('./game/words');
const { getNextTurn, getFirstTurn } = require('./game/turns');
const { tallyVotes } = require('./game/voting');
const { checkWin } = require('./game/win');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY || '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' });

app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// ── Session store ─────────────────────────────────────────────────────────────
const sessions = {}; // sessionId => { roomId, playerName, playerId }

// ── Inactivity timers ─────────────────────────────────────────────────────────
const inactivityTimers = {};
const INACTIVITY_WARN_MS = 30000;
const INACTIVITY_ELIM_MS = 60000;

function clearInactivity(playerId) {
  if (inactivityTimers[playerId]) {
    clearTimeout(inactivityTimers[playerId].warn);
    clearTimeout(inactivityTimers[playerId].elim);
    delete inactivityTimers[playerId];
  }
}

function startInactivityTimer(room, roomId, playerId) {
  clearInactivity(playerId);
  const player = room.players.find(p => p.id === playerId);
  if (!player) return;

  const warnTimer = setTimeout(async () => {
    const r = getRoom(roomId);
    if (!r || r.state !== 'playing' || r.currentTurnId !== playerId) return;
    io.to(playerId).emit('inactivity_warning', { secondsLeft: 30 });
    await broadcastAI(roomId, 'inactivityWarn', { playerName: player.name });
  }, INACTIVITY_WARN_MS);

  const elimTimer = setTimeout(async () => {
    const r = getRoom(roomId);
    if (!r || r.state !== 'playing' || r.currentTurnId !== playerId) return;
    const p = r.players.find(x => x.id === playerId);
    if (!p || p.eliminated) return;
    p.eliminated = true;
    io.to(roomId).emit('player_inactivity_eliminated', { playerId, playerName: p.name });
    io.to(roomId).emit('room_update', getPublicState(r));
    await broadcastAI(roomId, 'inactivityElim', { playerName: p.name });
    advanceTurn(r, roomId, true);
  }, INACTIVITY_ELIM_MS);

  inactivityTimers[playerId] = { warn: warnTimer, elim: elimTimer };
}

// ── AI Moderator ──────────────────────────────────────────────────────────────
async function getAIModeratorMessage(context, event) {
  const systemPrompt = `You are NEXUS, the AI moderator of an online social deduction game called "Imposter".
You are dramatic, witty, and slightly menacing. Keep messages SHORT (1-2 sentences max).
Speak with flair. Use emojis sparingly but effectively.
The game involves players giving word clues while one secret Imposter tries to blend in.`;

  const prompts = {
    playerJoin:      `Player "${context.playerName}" just joined the room. Welcome them dramatically.`,
    playerLeave:     `Player "${context.playerName}" disconnected. Comment on their absence.`,
    playerReconnect: `Player "${context.playerName}" reconnected! Welcome them back.`,
    gameStart:       `Game starting with ${context.playerCount} players. Category: "${context.hint}". Announce it!`,
    turnStart:       `It's ${context.playerName}'s turn to give a clue. Hype them with pressure.`,
    playerSkipped:   `${context.playerName} is offline and being skipped.`,
    clueGiven:       `${context.playerName} gave the clue: "${context.clue}". React briefly.`,
    votingStart:     `Voting phase has begun. Tell players to vote wisely. Be ominous.`,
    elimination:     `${context.playerName} eliminated with ${context.votes} votes. ${context.wasImposter ? 'They WERE the Imposter!' : 'They were NOT the Imposter...'} React!`,
    crewmatesWin:    `Crewmates win! Imposter was ${context.imposterName}. Victory!`,
    imposterWin:     `Imposter wins! ${context.imposterName} fooled everyone!`,
    tieVote:         `Tie vote! Fate chooses — ${context.playerName} is eliminated.`,
    roundEnd:        `Round ${context.round} complete. Vote time. Build suspense.`,
    inactivityWarn:  `${context.playerName} is taking too long! 30 seconds remaining!`,
    inactivityElim:  `${context.playerName} was eliminated for inactivity!`,
    hostKick:        `${context.playerName} was kicked from the room by the host.`,
    playAgain:       `New game starting! Same agents, new word. Let's go!`,
  };

  try {
    const completion = await groq.chat.completions.create({
      model: 'llama3-8b-8192',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: prompts[event] || `Say something about: ${event}` },
      ],
      max_tokens: 80,
      temperature: 0.9,
    });
    return completion.choices[0]?.message?.content?.trim() || getFallbackMessage(event, context);
  } catch (err) {
    console.error('Groq error:', err.message);
    return getFallbackMessage(event, context);
  }
}

function getFallbackMessage(event, ctx) {
  const f = {
    gameStart:       `🎮 Game begins! ${ctx.playerCount} players, one Imposter...`,
    turnStart:       `⏳ ${ctx.playerName}, your turn. Choose wisely.`,
    clueGiven:       `💬 "${ctx.clue}" — Interesting...`,
    votingStart:     `🗳️ Time to vote! Who is the Imposter?`,
    elimination:     `⚡ ${ctx.playerName} eliminated! ${ctx.wasImposter ? '✅ IMPOSTER!' : '❌ Innocent...'}`,
    crewmatesWin:    `🏆 Crewmates WIN! Imposter: ${ctx.imposterName}!`,
    imposterWin:     `😈 Imposter WINS! ${ctx.imposterName} fooled you all!`,
    playerJoin:      `👋 ${ctx.playerName} entered the room.`,
    playerLeave:     `💨 ${ctx.playerName} has vanished.`,
    playerReconnect: `⚡ ${ctx.playerName} is back!`,
    tieVote:         `⚖️ Tie! ${ctx.playerName} eliminated by fate.`,
    roundEnd:        `🔁 Round ${ctx.round} done. Prepare to vote...`,
    inactivityWarn:  `⏰ ${ctx.playerName}! 30 seconds or you're OUT!`,
    inactivityElim:  `💀 ${ctx.playerName} eliminated for inactivity!`,
    hostKick:        `🚪 ${ctx.playerName} removed by the host.`,
    playAgain:       `🔄 New game! Same room, new word!`,
  };
  return f[event] || '...';
}

async function broadcastAI(roomId, event, context) {
  const message = await getAIModeratorMessage(context, event);
  io.to(roomId).emit('ai_message', { message, event });
  return message;
}

function broadcastVoteCounts(room, roomId) {
  const counts = {};
  for (const [voterId, targetId] of Object.entries(room.votes)) {
    if (targetId) counts[targetId] = (counts[targetId] || 0) + 1;
  }
  const eligible = room.players.filter(p => !p.eliminated && p.connected);
  io.to(roomId).emit('vote_update', {
    voteCount: Object.keys(room.votes).length,
    total: eligible.length,
    counts,
    voters: Object.keys(room.votes),
  });
}

// ── Socket.io ─────────────────────────────────────────────────────────────────
io.on('connection', (socket) => {
  console.log(`🔌 Connected: ${socket.id}`);

  socket.on('join_room', ({ roomId, playerName, sessionId }) => {
    if (!roomId || !playerName) return;
    let room = getRoom(roomId);

    // Try reconnect
    if (sessionId && sessions[sessionId] && room) {
      const sess = sessions[sessionId];
      if (sess.roomId === roomId) {
        const existing = room.players.find(p => p.name === sess.playerName);
        if (existing) {          const oldId = existing.id;
          existing.id = socket.id;
          existing.connected = true;
          if (room.hostId === oldId) room.hostId = socket.id;
          if (room.currentTurnId === oldId) room.currentTurnId = socket.id;
          if (room.imposterId === oldId) room.imposterId = socket.id;
          // Re-map votes
          const newVotes = {};
          for (const [vid, tid] of Object.entries(room.votes)) {
            newVotes[vid === oldId ? socket.id : vid] = tid === oldId ? socket.id : tid;
          }
          room.votes = newVotes;
          room.clues.forEach(c => { if (c.playerId === oldId) c.playerId = socket.id; });
          sessions[sessionId].playerId = socket.id;

          socket.join(roomId);
          socket.data = { roomId, playerName: existing.name, sessionId };

          socket.emit('reconnected', {
            playerId: socket.id,
            roomState: getPublicState(room),
            isHost: room.hostId === socket.id,
            role: existing.role,
            word: existing.role === 'crewmate' ? room.word : null,
            hint: room.hint,
            gameState: room.state,
            sessionId,
          });

          io.to(roomId).emit('room_update', getPublicState(room));

          if (room.state === 'playing' && room.currentTurnId === socket.id) {
            startInactivityTimer(room, roomId, socket.id);
          }
          if (room.state === 'voting') {
            socket.emit('voting_started', { roomState: getPublicState(room) });
            broadcastVoteCounts(room, roomId);
          }
          broadcastAI(roomId, 'playerReconnect', { playerName: existing.name });
          return;
        }
      }
    }

    // If sessionId provided but reconnect failed (room deleted/stale), clear session
    if (sessionId && sessions[sessionId] && sessions[sessionId].roomId === roomId) {
      delete sessions[sessionId];
      socket.emit("session_not_found");
      return;
    }

    // Normal join
    if (!room) room = createRoom(roomId);
    if (room.state !== 'lobby') {
      socket.emit('error', { message: 'Game in progress. Cannot join mid-game.' });
      return;
    }
    if (room.players.length >= 10) {
      socket.emit('error', { message: 'Room is full (max 10 players).' });
      return;
    }

    const newSessionId = Date.now().toString(36) + Math.random().toString(36).slice(2);
    const player = { id: socket.id, name: playerName, connected: true, eliminated: false, role: null };
    addPlayer(roomId, player);
    socket.join(roomId);
    socket.data = { roomId, playerName, sessionId: newSessionId };
    sessions[newSessionId] = { roomId, playerName, playerId: socket.id };

    socket.emit('joined', {
      playerId: socket.id,
      roomState: getPublicState(room),
      isHost: room.hostId === socket.id,
      sessionId: newSessionId,
    });

    io.to(roomId).emit('room_update', getPublicState(room));
    broadcastAI(roomId, 'playerJoin', { playerName });
  });

  socket.on('start_game', async () => {
    const { roomId } = socket.data || {};
    const room = getRoom(roomId);
    if (!room || room.hostId !== socket.id) return;
    if (room.players.length < 2) { socket.emit('error', { message: 'Need at least 2 players.' }); return; }
    await startNewGame(room, roomId);
  });

  socket.on('play_again', async () => {
    const { roomId } = socket.data || {};
    const room = getRoom(roomId);
    if (!room || room.hostId !== socket.id || room.state !== 'ended') return;
    room.players.forEach(p => { p.eliminated = false; });
    room.players = room.players.filter(p => p.connected);
    if (room.players.length < 2) { socket.emit('error', { message: 'Need at least 2 connected players.' }); return; }
    await broadcastAI(roomId, 'playAgain', {});
    await startNewGame(room, roomId);
  });

  socket.on('kick_player', async ({ targetId }) => {
    const { roomId } = socket.data || {};
    const room = getRoom(roomId);
    if (!room || room.hostId !== socket.id || targetId === socket.id) return;
    const player = room.players.find(p => p.id === targetId);
    if (!player) return;
    const playerName = player.name;
    room.players = room.players.filter(p => p.id !== targetId);
    io.to(targetId).emit('kicked', { reason: 'You were removed by the host.' });
    io.to(roomId).emit('room_update', getPublicState(room));
    broadcastAI(roomId, 'hostKick', { playerName });
    if (room.state === 'playing' && room.currentTurnId === targetId) advanceTurn(room, roomId, true);
  });

  socket.on('typing', ({ isTyping }) => {
    const { roomId, playerName } = socket.data || {};
    if (!roomId) return;
    socket.to(roomId).emit('player_typing', { playerId: socket.id, playerName, isTyping });
  });

  socket.on('submit_clue', async ({ clue }) => {
    const { roomId } = socket.data || {};
    const room = getRoom(roomId);
    if (!room || room.state !== 'playing' || room.currentTurnId !== socket.id) return;
    const player = room.players.find(p => p.id === socket.id);
    if (!player || player.eliminated) return;
    const words = clue.trim().split(/\s+/).slice(0, 7);
    const word = words.join(' ');
    if (!word) return;
    clearInactivity(socket.id);
    socket.to(roomId).emit('player_typing', { playerId: socket.id, playerName: player.name, isTyping: false });
    const clueEntry = { playerId: socket.id, playerName: player.name, clue: word, round: room.round };
    room.clues.push(clueEntry);
    io.to(roomId).emit('clue_submitted', { clueEntry, roomState: getPublicState(room) });
    await broadcastAI(roomId, 'clueGiven', { playerName: player.name, clue: word });
    advanceTurn(room, roomId);
  });

  socket.on('submit_vote', async ({ targetId }) => {
    const { roomId } = socket.data || {};
    const room = getRoom(roomId);
    if (!room || room.state !== 'voting') return;
    const voter = room.players.find(p => p.id === socket.id);
    if (!voter || voter.eliminated || room.votes[socket.id]) return;
    room.votes[socket.id] = targetId;
    broadcastVoteCounts(room, roomId);
    const eligible = room.players.filter(p => !p.eliminated && p.connected);
    if (Object.keys(room.votes).length >= eligible.length) await resolveVoting(room, roomId);
  });

  socket.on('disconnect', async () => {
    const { roomId, playerName } = socket.data || {};
    if (!roomId) return;
    const room = getRoom(roomId);
    if (!room) return;
    clearInactivity(socket.id);
    const player = room.players.find(p => p.id === socket.id);
    if (player) {
      player.connected = false;
      io.to(roomId).emit('room_update', getPublicState(room));
      io.to(roomId).emit('player_typing', { playerId: socket.id, playerName, isTyping: false });
      await broadcastAI(roomId, 'playerLeave', { playerName });
      if (room.state === 'playing' && room.currentTurnId === socket.id) advanceTurn(room, roomId, true);
      if (room.state === 'voting') {
        const eligible = room.players.filter(p => !p.eliminated && p.connected);
        if (eligible.length > 0 && Object.keys(room.votes).length >= eligible.length) await resolveVoting(room, roomId);
      }
    }
    if (room.players.every(p => !p.connected)) {
      setTimeout(() => {
        const r = getRoom(roomId);
        if (r && r.players.every(p => !p.connected)) deleteRoom(roomId);
      }, 300000);
    }
  });
});

async function startNewGame(room, roomId) {
  const wordPack = getRandomWord();
  const { imposterId } = assignRoles(room.players);
  const firstTurn = getFirstTurn(room.players);
  Object.assign(room, {
    word: wordPack.word, hint: wordPack.hint, imposterId,
    currentTurnId: firstTurn, state: 'playing',
    clues: [], round: 1, votes: {},
  });
  room.players.forEach(p => {
    p.role = p.id === imposterId ? 'imposter' : 'crewmate';
    p.eliminated = false;
    io.to(p.id).emit('role_assigned', {
      role: p.role,
      word: p.role === 'imposter' ? null : wordPack.word,
      hint: wordPack.hint,
    });
  });
  io.to(roomId).emit('game_started', { roomState: getPublicState(room), currentTurnId: firstTurn });
  await broadcastAI(roomId, 'gameStart', { playerCount: room.players.length, hint: wordPack.hint });
  const first = room.players.find(p => p.id === firstTurn);
  if (first) { await broadcastAI(roomId, 'turnStart', { playerName: first.name }); startInactivityTimer(room, roomId, firstTurn); }
}

async function advanceTurn(room, roomId, skipped = false) {
  clearInactivity(room.currentTurnId);
  const roundClues = room.clues.filter(c => c.round === room.round);
  const totalActive = room.players.filter(p => !p.eliminated).length;

  if (roundClues.length >= totalActive) {
    if (room.round >= room.maxRounds) {
      room.state = 'voting';
      room.votes = {};
      io.to(roomId).emit('voting_started', { roomState: getPublicState(room) });
      await broadcastAI(roomId, 'votingStart', {});
      return;
    } else {
      room.round++;
      room.currentTurnId = getFirstTurn(room.players);
      io.to(roomId).emit('round_update', { round: room.round, roomState: getPublicState(room) });
      await broadcastAI(roomId, 'roundEnd', { round: room.round - 1 });
    }
  } else {
    const nextId = getNextTurn(room.players, room.currentTurnId);
    if (!nextId) return;
    room.currentTurnId = nextId;
  }

  io.to(roomId).emit('turn_changed', { currentTurnId: room.currentTurnId, roomState: getPublicState(room) });
  const nextPlayer = room.players.find(p => p.id === room.currentTurnId);
  if (nextPlayer) {
    if (skipped) await broadcastAI(roomId, 'playerSkipped', { playerName: nextPlayer.name });
    await broadcastAI(roomId, 'turnStart', { playerName: nextPlayer.name });
    startInactivityTimer(room, roomId, room.currentTurnId);
  }
}

async function resolveVoting(room, roomId) {
  const { eliminated, counts, tie } = tallyVotes(room.votes, room.players);
  const eliminatedPlayer = room.players.find(p => p.id === eliminated);
  if (eliminatedPlayer) eliminatedPlayer.eliminated = true;
  const wasImposter = eliminated === room.imposterId;

  io.to(roomId).emit('player_eliminated', {
    eliminatedId: eliminated,
    eliminatedName: eliminatedPlayer?.name,
    wasImposter, voteCount: counts[eliminated] || 0,
    voteCounts: counts, roomState: getPublicState(room),
  });

  if (tie) await broadcastAI(roomId, 'tieVote', { playerName: eliminatedPlayer?.name });
  await broadcastAI(roomId, 'elimination', { playerName: eliminatedPlayer?.name, votes: counts[eliminated] || 0, wasImposter });

  const winResult = checkWin(room.players, room.imposterId);
  if (winResult) {
    room.state = 'ended';
    const imposter = room.players.find(p => p.id === room.imposterId);
    io.to(roomId).emit('game_over', { winner: winResult.winner, reason: winResult.reason, imposterId: room.imposterId, imposterName: imposter?.name, word: room.word });
    room.players.forEach(p => io.to(p.id).emit('you_are_host', { isHost: p.id === room.hostId }));
    await broadcastAI(roomId, winResult.winner === 'crewmates' ? 'crewmatesWin' : 'imposterWin', { imposterName: imposter?.name });
    return;
  }

  room.state = 'playing';
  room.votes = {};
  room.round = 1;
  room.clues = [];
  room.currentTurnId = getFirstTurn(room.players);
  io.to(roomId).emit('game_continued', { currentTurnId: room.currentTurnId, roomState: getPublicState(room) });
  const nextPlayer = room.players.find(p => p.id === room.currentTurnId);
  if (nextPlayer) { await broadcastAI(roomId, 'turnStart', { playerName: nextPlayer.name }); startInactivityTimer(room, roomId, room.currentTurnId); }
}

// ── Word Admin API ────────────────────────────────────────────────────────────
app.use(express.json());

app.get('/api/words', (req, res) => res.json(getAllWords()));

app.post('/api/words/generate', async (req, res) => {
  const count = Math.min(parseInt((req.body && req.body.count) || 20), 50);
  const words = await generateAIWords(count);
  res.json({ generated: words, count: words.length });
});

app.post('/api/words/add', (req, res) => {
  const words = req.body && req.body.words;
  if (!Array.isArray(words)) return res.status(400).json({ error: 'words must be an array' });
  const added = addCustomWords(words);
  res.json({ added, total: getAllWords().total });
});

app.post('/api/words/refresh-ai', async (req, res) => {
  await ensureAIPool();
  const all = getAllWords();
  res.json({ ai: all.ai, count: all.ai.length });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log("Imposter Game v4 (AI Words) on port", PORT));
